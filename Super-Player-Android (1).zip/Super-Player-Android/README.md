# Super Player Android — development build

This is a source project, not a prebuilt APK. It bundles all 38 JavaScript modules from the supplied Synthetiq Module Bundle and provides an Android WebView-based JavaScript execution surface plus native Media3 playback.

## Build
- Install Android Studio (JDK 17 recommended) and Android SDK 35.
- Open this folder in Android Studio, allow Gradle sync, then Build > Build APK(s).
- Or run `./gradlew assembleDebug` if a Gradle wrapper is added / available. This archive does not include a wrapper JAR.

## Runtime design
- Module JS and module.json are stored under `app/src/main/assets/modules/`.
- `MainActivity` exposes module files, a constrained HTTP request bridge, and native playback to the UI.
- UI calls conventional entry points (`searchResults`, `extractDetails`, `extractEpisodes`, `extractStreamUrl`) when present. Module contracts differ and this generic adapter is intentionally best-effort.
- Native playback uses AndroidX Media3 ExoPlayer and provider-supplied headers when available.
- CloudStream extensions are not included: CloudStream extensions are Kotlin/JVM plugins targeting CloudStream APIs, not this JavaScript contract. Integrating them would require a separate plugin runtime or porting each extension.

## Honest test status
- Archive integrity: checked by extracting the original 38 nested module ZIPs.
- Included module count: 38.
- Contract versions in supplied manifests: 35 v4 and 3 v3.
- Android APK build: NOT run in this environment (Android SDK / Gradle toolchain unavailable).
- Live provider search/playback: NOT verified; providers can change, require cookies/headers, or return unsupported formats.
- The generic adapter does not guarantee that every module will work. Some providers need per-module adapters and output normalization.

## Safety / legal
Only use providers and streams you are authorized to access. This app does not include media files or guarantee any provider's legality or availability.

## Reference
CloudStream repository: https://github.com/recloudstream/cloudstream
CloudStream extension guide: https://recloudstream.github.io/csdocs/devs/gettingstarted/

## Build without installing Android Studio locally (GitHub Actions)
1. Upload this project folder's contents to a new GitHub repository (the `.github/workflows/android-apk.yml` workflow is included).
2. In the repository, open **Actions** and enable workflows if GitHub asks.
3. Select **Build Super Player APK** → **Run workflow**.
4. When the run completes successfully, open that run and download the `Super-Player-debug-apk` artifact. Extract it to get `app-debug.apk`.
5. Transfer the APK to your Android phone and install it. Only install APKs from projects you trust.

The cloud workflow has been added but has **not been run from this environment**. It does not mean the project has compiled; a failed run will show the actual compiler/build error in GitHub Actions.
