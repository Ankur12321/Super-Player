/* ============================================================
 * Synthetiq Player compatibility layer (prepended during conversion).
 * 1) fetchv2 JSON-body compat: the source runtime hands JSON back as a text
 *    body (responseClass "json"); the Player delivers JSON with an EMPTY body
 *    (data only via res.json()). Rebuild body/text() from json().
 * ============================================================ */
(function () {
  var realFetchv2 = globalThis.fetchv2;
  if (typeof realFetchv2 !== 'function') return;
  globalThis.fetchv2 = async function (url, headers, method, body, options) {
    var res = await realFetchv2(url, headers, method, body, options);
    try {
      var empty = !res || !res.body;
      var ct = String((res && res.headers && (res.headers['content-type'] || res.headers['Content-Type'])) || '');
      var wantsJson = options && String(options.responseClass || '').toLowerCase() === 'json';
      if (empty && (wantsJson || /json/i.test(ct)) && res && typeof res.json === 'function') {
        var data = await res.json();
        var text = JSON.stringify(data);
        return Object.assign({}, res, {
          body: text,
          text: async function () { return text; },
          json: async function () { return data; },
        });
      }
    } catch (e) { /* leave the response as-is */ }
    return res;
  };
})();

"use strict";

(() => {
  const BASE_URL = "https://mangakatana.com";
  const DEFAULT_HEADERS = {
    Accept: "text/html,application/xhtml+xml",
    Referer: `${BASE_URL}/`,
  };
  // The site answers bursts inside a ~1s window with an empty HTTP 200 body,
  // so transport retries and a short-lived GET cache are required for a
  // reliable search -> details -> chapters -> images walk.
  const RETRYABLE_STATUS = new Set([403, 408, 425, 429, 500, 502, 503, 504]);
  const MAX_ATTEMPTS = 4;
  const searchSeenByQuery = new Map();
  const GET_CACHE_TTL = 45_000;
  const getCache = new Map();
  // Keep a floor between requests so normal walks never trip the window. Measured
  // 2026-09-22: bursts get empty 200s and ~1.3 s spacing still alternated empty/full;
  // identical requests ~3 s apart were always served. Retries therefore wait long
  // enough to leave the bad window instead of immediately re-triggering it.
  const MIN_REQUEST_SPACING = 2200;
  const RETRY_WAITS = [0, 2200, 3600, 5200];
  let lastRequestAt = 0;

  function sleep(milliseconds) {
    return new Promise((resolve) => {
      // Prefer the scope-provided timer (works in the app runtime AND the Node test
      // shims); fall back to globalThis for sandboxes with a custom global object.
      const timer =
        (typeof setTimeout === "function" && setTimeout) ||
        (typeof globalThis === "object" && globalThis && typeof globalThis.setTimeout === "function" ? globalThis.setTimeout : null);
      if (timer) timer(resolve, milliseconds);
      else Promise.resolve().then(resolve);
    });
  }

  function decodeEntities(value) {
    const named = { amp: "&", apos: "'", gt: ">", lt: "<", nbsp: " ", quot: '"' };
    return String(value || "")
      .replace(/&#x([0-9a-f]+);/gi, (_, hex) => String.fromCodePoint(parseInt(hex, 16)))
      .replace(/&#([0-9]+);/g, (_, decimal) => String.fromCodePoint(parseInt(decimal, 10)))
      .replace(/&([a-z]+);/gi, (match, name) => named[name.toLowerCase()] || match);
  }

  function stripHTML(value) {
    return decodeEntities(
      String(value || "")
        .replace(/<script\b[\s\S]*?<\/script>/gi, " ")
        .replace(/<style\b[\s\S]*?<\/style>/gi, " ")
        .replace(/<br\s*\/?\s*>/gi, "\n")
        .replace(/<[^>]+>/g, " "),
    )
      .replace(/[ \t]+/g, " ")
      .replace(/\s*\n\s*/g, "\n")
      .trim();
  }

  function attribute(tag, name) {
    const match = String(tag || "").match(
      new RegExp(`\\b${name}\\s*=\\s*(["'])([\\s\\S]*?)\\1`, "i"),
    );
    return match ? decodeEntities(match[2].trim()) : "";
  }

  async function responseText(response) {
    if (!response) return "";
    if (typeof response.text === "function") {
      const value = await response.text();
      if (typeof value === "string") return value;
    }
    if (typeof response.body === "string") return response.body;
    return "";
  }

  async function fetchDirect(url, options = {}) {
    if (typeof globalThis.fetchv2 !== "function") {
      throw new Error("MangaKatana requires the fetchv2 bridge.");
    }
    const method = options.method || "GET";
    const cacheKey = `${method} ${url}`;
    if (method === "GET" && !options.headers) {
      const cached = getCache.get(cacheKey);
      if (cached && Date.now() - cached.at < GET_CACHE_TTL) return cached.body;
    }
    let lastError = null;
    for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt += 1) {
      if (attempt > 1) await sleep(RETRY_WAITS[attempt - 1] || 5200);
      const spacingWait = lastRequestAt + MIN_REQUEST_SPACING - Date.now();
      if (spacingWait > 0) await sleep(spacingWait);
      lastRequestAt = Date.now();
      let response = null;
      try {
        response = await globalThis.fetchv2(
          url,
          { ...DEFAULT_HEADERS, ...(options.headers || {}) },
          method,
          options.body || null,
          {
            followRedirects: true,
            maxBytesHint: options.maxBytesHint || null,
            responseClass: options.responseClass || "html",
          },
        );
      } catch (error) {
        // Bridge/network failures (timeouts, aborted sockets) are transient.
        lastError = error instanceof Error ? error : new Error(String(error));
        continue;
      }
      const status = Number(response && response.status);
      if (!response || response.ok === false || (status && (status < 200 || status >= 300))) {
        lastError = new Error(`MangaKatana request failed with HTTP ${status || "error"}.`);
        if (status && !RETRYABLE_STATUS.has(status)) break;
        continue;
      }
      if (response.bodyDropped) {
        throw new Error(`MangaKatana response was dropped: ${response.dropReason || "size policy"}.`);
      }
      const body = await responseText(response);
      if (body) {
        if (method === "GET" && !options.headers) {
          if (getCache.size >= 16) getCache.delete(getCache.keys().next().value);
          getCache.set(cacheKey, { at: Date.now(), body });
        }
        return body;
      }
      // Empty 200 bodies are this host's rate-limit signal; retry them.
      lastError = new Error("MangaKatana returned an empty response.");
    }
    throw lastError || new Error("MangaKatana request failed.");
  }

  function absoluteURL(value) {
    const input = String(value || "").trim();
    if (!input) return "";
    if (input.startsWith("https://")) return input;
    if (input.startsWith("//")) return `https:${input}`;
    if (input.startsWith("/")) return `${BASE_URL}${input}`;
    return `${BASE_URL}/${input}`;
  }

  function normalizedSeriesURL(value) {
    const input = String(value || "").trim();
    const match = input.match(/(?:https:\/\/mangakatana\.com)?\/?manga\/([a-z0-9][a-z0-9.-]*)/i);
    if (match) return `${BASE_URL}/manga/${match[1]}`;
    if (/^[a-z0-9][a-z0-9.-]*$/i.test(input)) return `${BASE_URL}/manga/${input}`;
    throw new Error("Invalid MangaKatana series identifier.");
  }

  function normalizedChapterURL(value) {
    const input = String(value || "").trim();
    const match = input.match(
      /(?:https:\/\/mangakatana\.com)?\/?manga\/([a-z0-9][a-z0-9.-]*)\/(c[0-9]+(?:\.[0-9]+)?(?:-[a-z0-9-]+)?|v[0-9]+c[0-9]+(?:\.[0-9]+)?|fc)(?:[?#]|$)/i,
    );
    if (match) return `${BASE_URL}/manga/${match[1]}/${match[2].toLowerCase()}`;
    throw new Error("Invalid MangaKatana chapter identifier.");
  }

  function chapterNumber(title, href) {
    const fromHref = String(href || "").match(/\/(?:v[0-9]+)?c([0-9]+(?:\.[0-9]+)?)(?:-[a-z0-9-]+)?(?:[?#]|$)/i);
    if (fromHref) return Number(fromHref[1]);
    const fromTitle = String(title || "").match(/(?:chapter|ch\.?)[\s#:-]*([0-9]+(?:\.[0-9]+)?)/i);
    return fromTitle ? Number(fromTitle[1]) : null;
  }

  function parseSearchHTML(html) {
    const items = [];
    const seen = new Set();
    const pattern = /<h3 class="title">\s*<a href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi;
    let match;
    while ((match = pattern.exec(html)) !== null) {
      const href = absoluteURL(decodeEntities(match[1]));
      if (!/\/manga\//i.test(href) || seen.has(href)) continue;
      const title = stripHTML(match[2]);
      if (!title) continue;
      // Cover images sit before the title inside the same result card.
      const previousTitle = html.lastIndexOf('<h3 class="title">', match.index - 1);
      const start = previousTitle === -1 ? Math.max(0, match.index - 800) : previousTitle + 1;
      const window = html.slice(start, match.index);
      const imageCandidates = Array.from(
        window.matchAll(/<img\b[^>]*src=(["'])(https:\/\/[^"']+)\1/gi),
      );
      const image = imageCandidates.length
        ? decodeEntities(imageCandidates[imageCandidates.length - 1][2])
        : "";
      seen.add(href);
      items.push({ id: href, href, title, image });
    }
    const totalMatch = String(html).match(/Search results\s*\((\d+)\)/i);
    const total = totalMatch ? Number(totalMatch[1]) : items.length;
    const hasPageLink = /href=["'][^"']*page\/[0-9]+[^"']*search=/i.test(html)
      || /href=["'][^"']*search=[^"']*page=/i.test(html)
      || /href=["'][^"']*\/(?:new-manga|latest)\/page\/[0-9]+/i.test(html);
    return {
      items,
      hasMore: hasPageLink || (Number.isFinite(total) && items.length > 0 && items.length < total),
    };
  }

  function parseListHTML(html) {
    return parseSearchHTML(html);
  }

  function parseDetailsHTML(html, href) {
    const title =
      stripHTML((html.match(/<h1\b[^>]*>([\s\S]*?)<\/h1>/i) || [])[1] || "")
      || stripHTML((html.match(/og:title" content="([^"]+)"/i) || [])[1] || "");
    if (!title) throw new Error("MangaKatana details did not contain a title.");

    const image =
      decodeEntities((html.match(/og:image" content="([^"]+)"/i) || [])[1] || "")
      || decodeEntities((html.match(/<div class="cover[\s\S]*?<img\b[^>]*src=(["'])(https:\/\/[^"']+)\1/i) || [])[2] || "");

    const authors = Array.from(
      html.matchAll(/href="https:\/\/mangakatana\.com\/author\/[^"]*"[^>]*>([\s\S]*?)<\/a>/gi),
    )
      .map((entry) => stripHTML(entry[1]))
      .filter(Boolean);

    const genres = Array.from(
      html.matchAll(/href="https:\/\/mangakatana\.com\/genre\/[^"]*"[^>]*>([\s\S]*?)<\/a>/gi),
    )
      .map((entry) => stripHTML(entry[1]))
      .filter((value) => value && !/genres?/i.test(value));

    let status = "Unknown";
    const statusMatch = html.match(
      /Status:[\s\S]*?<div class="d-cell-small value status[^"]*">([\s\S]*?)<\/div>/i,
    );
    if (statusMatch) status = stripHTML(statusMatch[1]) || status;

    let description = "";
    // The summary block is `<div class="summary"><div class="label">Description</div><p>…</p></div>`;
    // the old non-greedy first-</div> capture grabbed only the label (empty text).
    const summaryP = html.match(/<div class="summary">[\s\S]*?<p>([\s\S]*?)<\/p>/i);
    if (summaryP) {
      description = stripHTML(summaryP[1]).replace(/^(?:Description|Summary):?\s*/i, "").trim();
    }
    if (!description) {
      const summaryMatch = html.match(/<div class="summary">([\s\S]*?)<\/div>/i)
        || html.match(/class="summary"[\s\S]*?<div class="text">([\s\S]*?)<\/div>/i);
      if (summaryMatch) {
        description = stripHTML(summaryMatch[1]).replace(/^(?:Description|Summary):?\s*/i, "").trim();
      }
    }
    if (!description) {
      const metaMatch = html.match(/<meta\s+name="description"\s+content="([^"]+)"/i);
      if (metaMatch) {
        description = stripHTML(decodeEntities(metaMatch[1])).replace(/^(?:Description|Summary):?\s*/i, "").trim();
      }
    }

    return {
      id: href,
      href,
      url: href,
      title,
      description,
      image,
      authors,
      author: authors.join(", "),
      genres,
      status,
    };
  }

  function primaryChapterTableHTML(html) {
    // MangaKatana also renders chapter links for related titles on a series
    // page. The selected title's complete chapter list is the only table in a
    // .chapters container; parsing the entire document mixes the two lists.
    const match = String(html || "").match(
      /<div\b[^>]*class=(["'])[^"']*\bchapters\b[^"']*\1[^>]*>\s*<table\b[^>]*>[\s\S]*?<tbody\b[^>]*>([\s\S]*?)<\/tbody>/i,
    );
    return match ? match[2] : "";
  }

  function parseChaptersHTML(html, seriesURL) {
    const chapters = [];
    const seen = new Set();
    const chapterMarkup = primaryChapterTableHTML(html);
    if (!chapterMarkup) return chapters;

    const seriesPrefix = `${normalizedSeriesURL(seriesURL).toLowerCase()}/`;
    const pattern = /<div\b[^>]*class=(["'])[^"']*\bchapter\b[^"']*\1[^>]*>\s*<a\b[^>]*href=(["'])([\s\S]*?)\2[^>]*>([\s\S]*?)<\/a>/gi;
    let match;
    while ((match = pattern.exec(chapterMarkup)) !== null) {
      const href = absoluteURL(decodeEntities(match[3]));
      if (!href.toLowerCase().startsWith(seriesPrefix) || seen.has(href)) continue;
      if (!/\/(?:c[0-9]+(?:\.[0-9]+)?(?:-[a-z0-9-]+)?|v[0-9]+c[0-9]+(?:\.[0-9]+)?|fc)(?:[?#]|$)/i.test(href)) {
        continue;
      }
      const title = stripHTML(match[4]);
      if (!title) continue;
      chapters.push({
        id: href,
        href,
        url: href,
        title,
        number: chapterNumber(title, href),
        releaseDate: null,
        language: "en",
      });
      seen.add(href);
    }
    return chapters;
  }

  function parseImagesHTML(html) {
    const pages = [];
    const seen = new Set();
    const thzq = String(html).match(/var\s+thzq\s*=\s*(\[[\s\S]*?\]);/i);
    if (thzq) {
      let list = [];
      try {
        list = JSON.parse(thzq[1].replace(/'/g, '"'));
      } catch (_) {
        list = Array.from(thzq[1].matchAll(/'(https:\/\/[^']+)'/g)).map((entry) => entry[1]);
      }
      for (const url of list) {
        const absolute = absoluteURL(url);
        if (!absolute.startsWith("https://") || seen.has(absolute)) continue;
        if (!/\.(?:jpg|jpeg|png|webp|avif|gif)(?:\?|$)/i.test(absolute) && !/\/token\//i.test(absolute)) {
          continue;
        }
        pages.push({
          url: absolute,
          headers: {
            Accept: "image/avif,image/webp,image/*,*/*",
            Referer: `${BASE_URL}/`,
          },
        });
        seen.add(absolute);
      }
    }
    if (!pages.length) {
      const pattern = /<img\b[^>]*>/gi;
      let match;
      while ((match = pattern.exec(html)) !== null) {
        const tag = match[0];
        const url = attribute(tag, "data-src") || attribute(tag, "src");
        if (!url.startsWith("https://") || seen.has(url)) continue;
        if (/\/static\/img\//i.test(url) || /\/imgs\/cover\//i.test(url)) continue;
        if (!/\.(?:jpg|jpeg|png|webp|avif|gif)(?:\?|$)/i.test(url) && !/\/token\//i.test(url)) continue;
        pages.push({
          url,
          headers: {
            Accept: "image/avif,image/webp,image/*,*/*",
            Referer: `${BASE_URL}/`,
          },
        });
        seen.add(url);
      }
    }
    return pages;
  }

  function searchURL(query, page) {
    const currentPage = Math.max(1, Number(page) || 1);
    if (query === "__feed:popular" || query === "__feed:latest") {
      const path = query === "__feed:popular" ? "/new-manga" : "/latest";
      return currentPage <= 1 ? `${BASE_URL}${path}` : `${BASE_URL}${path}/page/${currentPage}`;
    }
    const text = String(query || "").trim().slice(0, 200);
    if (currentPage <= 1) {
      return `${BASE_URL}/?search=${encodeURIComponent(text)}`;
    }
    return `${BASE_URL}/page/${currentPage}?search=${encodeURIComponent(text)}`;
  }

  async function searchResults(query, page = 1) {
    const html = await fetchDirect(searchURL(query, page), { maxBytesHint: 2 * 1024 * 1024 });
    const parsed = query === "__feed:popular" || query === "__feed:latest"
      ? parseListHTML(html)
      : parseSearchHTML(html);
    const key = String(query || "");
    if (Number(page) <= 1 || !searchSeenByQuery.has(key)) searchSeenByQuery.set(key, new Set());
    const seen = searchSeenByQuery.get(key);
    parsed.items = parsed.items.filter((item) => {
      if (seen.has(item.id)) return false;
      seen.add(item.id);
      return true;
    });
    return parsed;
  }

  async function extractDetails(id) {
    const href = normalizedSeriesURL(id);
    return parseDetailsHTML(await fetchDirect(href, { maxBytesHint: 3 * 1024 * 1024 }), href);
  }

  async function extractChapters(id) {
    const href = normalizedSeriesURL(id);
    const chapters = parseChaptersHTML(
      await fetchDirect(href, { maxBytesHint: 8 * 1024 * 1024 }),
      href,
    );
    if (!chapters.length) throw new Error("MangaKatana returned no chapters for this series.");
    return chapters;
  }

  async function extractImages(id) {
    const href = normalizedChapterURL(id);
    const pages = parseImagesHTML(await fetchDirect(href, { maxBytesHint: 4 * 1024 * 1024 }));
    if (!pages.length) throw new Error("MangaKatana chapter returned no readable pages.");
    return pages;
  }

  async function discoveryHome() {
    // Serialized on purpose: parallel feed requests trip this host's
    // empty-body rate window (see fetchDirect above).
    const popular = await searchResults("__feed:popular", 1);
    const latest = await searchResults("__feed:latest", 1);
    return {
      sections: [
        { id: "popular", title: "New Manga", items: (popular.items || []).slice(0, 30), viewAll: { mode: "feed", feedId: "popular" } },
        { id: "latest", title: "Latest Updates", items: (latest.items || []).slice(0, 30), viewAll: { mode: "feed", feedId: "latest" } },
      ],
    };
  }

  async function discoveryFeed(feedID, page = 1) {
    const feed = String(feedID || "").toLowerCase() === "latest" ? "latest" : "popular";
    const result = await searchResults(`__feed:${feed}`, page);
    // App cap: 50 items per feed page — slice regardless of page size.
    if (result && Array.isArray(result.items)) {
      return Object.assign({}, result, { items: result.items.slice(0, 50) });
    }
    if (Array.isArray(result)) {
      return { items: result.slice(0, 50), page: Number(page) || 1, hasMore: result.length >= 50 };
    }
    return result;
  }

  const handlers = {
    searchResults,
    extractDetails,
    extractChapters,
    extractImages,
    discoveryHome,
    discoveryFeed,
  };
  globalThis.SynthetiqModule = handlers;
  Object.assign(globalThis, handlers);
})();


/* ============================================================
 * Synthetiq Player compatibility layer (appended during conversion).
 * The Player image runtime requires searchResults to return a plain ARRAY
 * (the source format allows { items, hasMore }) and calls it with 0-based
 * pages; source modules expect 1-based pages.
 * ============================================================ */
(function () {
  var original = globalThis.searchResults;
  if (typeof original !== 'function') return;
  async function adapted(query, page) {
    var pageArg = (Number(page) || 0) < 1 ? 1 : Number(page);
    var result = await original(query, pageArg);
    if (result && !Array.isArray(result) && Array.isArray(result.items)) return result.items;
    if (result == null) return [];
    return result;
  }
  globalThis.searchResults = adapted;
  if (globalThis.SynthetiqModule && typeof globalThis.SynthetiqModule === 'object') {
    globalThis.SynthetiqModule.searchResults = adapted;
  }
})();
