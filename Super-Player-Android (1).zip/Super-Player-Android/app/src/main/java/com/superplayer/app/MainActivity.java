package com.superplayer.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.content.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeUnit;
import okhttp3.*;

public class MainActivity extends Activity {
  WebView web; OkHttpClient http = new OkHttpClient.Builder().connectTimeout(18,TimeUnit.SECONDS).readTimeout(25,TimeUnit.SECONDS).followRedirects(true).build();
  @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(android.graphics.Color.rgb(9,9,15)); getWindow().setNavigationBarColor(android.graphics.Color.rgb(9,9,15)); web=new WebView(this); web.setBackgroundColor(0xff09090f); WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setMediaPlaybackRequiresUserGesture(false); s.setAllowFileAccess(true); s.setAllowContentAccess(true); web.addJavascriptInterface(new Bridge(),"SPNative"); web.setWebChromeClient(new WebChromeClient()); web.setWebViewClient(new WebViewClient()); setContentView(web); web.loadUrl("file:///android_asset/index.html"); }
  class Bridge {
    @JavascriptInterface public String catalog(){return readAsset("catalog.json");}
    @JavascriptInterface public String moduleJs(String slug){try{return readAsset("modules/"+slug+"/index.js");}catch(Exception e){return "";}}
    @JavascriptInterface public String moduleManifest(String slug){try{return readAsset("modules/"+slug+"/module.json");}catch(Exception e){return "{}";}}
    @JavascriptInterface public String request(String url,String headersJson,String method,String body){
      try { if(url==null || !(url.startsWith("https://")||url.startsWith("http://"))) return err("Only HTTP(S) URLs are allowed"); HttpUrl parsed=HttpUrl.parse(url); if(parsed==null) return err("Invalid URL");
        Request.Builder rb=new Request.Builder().url(url); JSONObject h=new JSONObject(headersJson==null?"{}":headersJson); java.util.Iterator<String> it=h.keys(); while(it.hasNext()){String k=it.next(); if(!k.equalsIgnoreCase("host")&&!k.equalsIgnoreCase("content-length")) rb.header(k,h.optString(k));}
        String m=(method==null?"GET":method).toUpperCase(); RequestBody reqBody=null; if(!m.equals("GET")&&!m.equals("HEAD")){String ct=h.optString("Content-Type","application/x-www-form-urlencoded; charset=utf-8"); reqBody=RequestBody.create(MediaType.parse(ct),body==null?"":body);} rb.method(m,reqBody);
        try(Response r=http.newCall(rb.build()).execute()){String text=r.body()==null?"":r.body().string(); JSONObject out=new JSONObject(); out.put("ok",r.isSuccessful());out.put("status",r.code());out.put("url",r.request().url().toString());out.put("headers",new JSONObject());out.put("body",text); return out.toString();}
      } catch(Exception e){return err(e.getClass().getSimpleName()+": "+e.getMessage());}}
    @JavascriptInterface public void play(String url,String headersJson,String title){runOnUiThread(()->{Intent i=new Intent(MainActivity.this,PlayerActivity.class);i.putExtra("url",url);i.putExtra("headers",headersJson==null?"{}":headersJson);i.putExtra("title",title==null?"Super Player":title);startActivity(i);});}
    @JavascriptInterface public void log(String msg){android.util.Log.d("SuperPlayer",msg==null?"":msg);}
  }
  String readAsset(String p){try(InputStream in=getAssets().open(p);ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);return out.toString("UTF-8");}catch(Exception e){return "";}}
  String err(String m){try{JSONObject o=new JSONObject();o.put("ok",false);o.put("status",0);o.put("body","");o.put("error",m);return o.toString();}catch(Exception e){return "{}";}}
  @Override public void onBackPressed(){if(web!=null && web.canGoBack())web.goBack();else super.onBackPressed();}
}
