plugins { id("com.android.application") }

android {
    namespace = "com.superplayer.app"
    compileSdk = 35
    defaultConfig { applicationId = "com.superplayer.app"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "0.1.0" }
}

dependencies {
    implementation("androidx.media3:media3-exoplayer:1.5.1")
    implementation("androidx.media3:media3-ui:1.5.1")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.mozilla:rhino:1.7.15")
}
