# Super Player Android — development build

This is a source project, not a prebuilt APK. It bundles all 38 JavaScript modules from the supplied Synthetiq Module Bundle and provides an Android WebView-based JavaScript execution surface plus native Media3 playback.

## Build
- Install Android Studio (JDK 17 recommended) and Android SDK 35.
- Open this folder in Android Studio, allow Gradle sync, then Build > Build APK(s).
- Or run `./gradlew assembleDebug` if a Gradle wrapper is added / available. This archive does not include a wrapper JAR.

## Runtime design
- Module JS and module.json are stored under `app/src/main/assets/modules/`.
- `MainActivity` exposes module files, a constrained HTTP request bridge, and native playback to the UI.
- UI calls conventional entry points (`searchResults`, `extractDetails`, `extractEpisodes`, `extractStreamUrl`) when present. Module contracts differ and this generic adapter is intentionally best-effort.
- Native playback uses AndroidX Media3 ExoPlayer and provider-supplied headers when available.
- CloudStream extensions are not included: CloudStream extensions are Kotlin/JVM plugins targeting CloudStream APIs, not this JavaScript contract. Integrating them would require a separate plugin runtime or porting each extension.

## Honest test status
- Archive integrity: checked by extracting the original 38 nested module ZIPs.
- Included module count: 38.
- Contract versions in supplied manifests: 35 v4 and 3 v3.
- Android APK build: NOT run in this environment (Android SDK / Gradle toolchain unavailable).
- Live provider search/playback: NOT verified; providers can change, require cookies/headers, or return unsupported formats.
- The generic adapter does not guarantee that every module will work. Some providers need per-module adapters and output normalization.

## Safety / legal
Only use providers and streams you are authorized to access. This app does not include media files or guarantee any provider's legality or availability.

## Reference
CloudStream repository: https://github.com/recloudstream/cloudstream
CloudStream extension guide: https://recloudstream.github.io/csdocs/devs/gettingstarted/
